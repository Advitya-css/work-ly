import { NextResponse } from "next/server";

import { getCurrentUser } from "@/lib/auth";
import { createDocument, listDocumentsByUserId } from "@/lib/db/documents";
import { checkRateLimit, minutesUntil } from "@/lib/rate-limit";
import { storageProvider } from "@/lib/storage";
import { MAX_RESUME_SIZE_BYTES, validateResumeFile } from "@/lib/validations/document";

const UPLOAD_LIMIT = 10;
const UPLOAD_WINDOW_SECONDS = 10 * 60;

// Multipart form-data adds a boundary, per-part headers, and the field name
// around the actual file bytes. 64KB is generous headroom for that overhead
// on top of the real file-size limit, without being large enough to matter
// for the memory-exhaustion concern below.
const MAX_UPLOAD_REQUEST_BYTES = MAX_RESUME_SIZE_BYTES + 64 * 1024;

export const runtime = "nodejs";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const documents = await listDocumentsByUserId(user.id);
  return NextResponse.json({ documents });
}

/** Upload a resume (PDF/DOCX). Storing and validating happens here; parsing is a separate call - see [id]/parse/route.ts - so the client can show distinct "uploading" vs "parsing" states. */
export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const rateLimit = await checkRateLimit("resume-upload", user.id, {
    limit: UPLOAD_LIMIT,
    windowSeconds: UPLOAD_WINDOW_SECONDS,
    userId: user.id,
  });
  if (!rateLimit.allowed) {
    return NextResponse.json(
      { error: `Too many uploads. Please try again in ${minutesUntil(rateLimit.resetAt)} minute(s).` },
      { status: 429 },
    );
  }

  // Reject an oversized upload BEFORE request.formData() runs. formData()
  // buffers the entire body into memory first and only then hands back a
  // File whose .size can be checked - by which point the memory cost this
  // check exists to avoid has already been paid regardless of the outcome.
  // Real browser uploads always send Content-Length for a body of known
  // size (a File/FormData body), so a missing header is itself treated as
  // untrustworthy rather than silently allowed through uncapped.
  const declaredLength = Number(request.headers.get("content-length") ?? "");
  if (!Number.isFinite(declaredLength) || declaredLength <= 0) {
    return NextResponse.json({ error: "Couldn't determine the upload size." }, { status: 411 });
  }
  if (declaredLength > MAX_UPLOAD_REQUEST_BYTES) {
    return NextResponse.json(
      { error: `File is too large. The limit is ${MAX_RESUME_SIZE_BYTES / (1024 * 1024)}MB.` },
      { status: 413 },
    );
  }

  const formData = await request.formData();
  const file = formData.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "No file provided." }, { status: 400 });
  }

  const validation = validateResumeFile({ name: file.name, type: file.type, size: file.size });
  if (!validation.ok || !validation.fileType) {
    return NextResponse.json({ error: validation.error }, { status: 422 });
  }

  const buffer = Buffer.from(await file.arrayBuffer());

  // Defense in depth: confirm the bytes actually are what they claim to
  // be, not just trusting the extension/declared mime type.
  const { fileTypeFromBuffer } = await import("file-type");
  const sniffed = await fileTypeFromBuffer(buffer);
  const sniffedOk =
    (validation.fileType === "PDF" && sniffed?.mime === "application/pdf") ||
    (validation.fileType === "DOCX" &&
      sniffed?.mime === "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
  if (!sniffedOk) {
    return NextResponse.json(
      { error: "The file's contents don't match a valid PDF or DOCX." },
      { status: 422 },
    );
  }

  const storageKey = `resumes/${user.id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
  await storageProvider.upload({
    key: storageKey,
    data: buffer,
    contentType: file.type || "application/octet-stream",
  });

  const document = await createDocument({
    userId: user.id,
    fileName: file.name,
    fileType: validation.fileType,
    fileSizeBytes: file.size,
    storageKey,
  });

  return NextResponse.json({ document });
}
