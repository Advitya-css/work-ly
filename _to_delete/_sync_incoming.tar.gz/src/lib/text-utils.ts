/**
 * Pure text helpers with no server-only dependencies.
 *
 * These live apart from lib/scoring/shared.ts and lib/discovery/normalize.ts
 * - both of which are server-only - because the search engine runs in the
 * browser. Client-side ranking needs exactly these functions and nothing
 * else from those modules, and importing them from there would drag the
 * scoring engine and the job parser into the client bundle.
 *
 * Both server-side modules re-export from here, so there is still only one
 * implementation. That matters: if the client canonicalised text even
 * slightly differently from the server, ranking in the browser would
 * disagree with dedup on the server, and the same job could appear twice.
 */

/** Lowercase, punctuation-free, single-spaced - the canonical comparison form. */
export function canonical(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** The scoring engine's variant: keeps alphanumerics, folds separators to spaces. */
export function normalizeToken(s: string): string {
  return s.trim().toLowerCase().replace(/[.\-_/]/g, " ").replace(/\s+/g, " ");
}

/**
 * Loose skill-name equality. Substring matching in both directions catches
 * "React" vs "React.js" and "SQL" vs "Advanced SQL", with a length floor so
 * two-letter fragments can't match everything.
 */
export function skillsMatch(a: string, b: string): boolean {
  const na = normalizeToken(a);
  const nb = normalizeToken(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  return na.length > 2 && nb.length > 2 && (na.includes(nb) || nb.includes(na));
}
