import { NextResponse } from "next/server";

import { getCurrentUser } from "@/lib/auth";
import { deleteDocument, getDocumentById } from "@/lib/db/documents";
import { storageProvider } from "@/lib/storage";

export const runtime = "nodejs";

const CONTENT_TYPES = {
  PDF: "application/pdf",
  DOCX: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
} as const;

/**
 * Builds a `Content-Disposition` header safely for an arbitrary, user-
 * supplied filename.
 *
 * Stripping only `"` (the previous approach) leaves control characters -
 * most importantly CR/LF - in the header value. Browsers and the
 * underlying HTTP libraries generally refuse a raw CRLF in a header value
 * before it could become full response-splitting, but "generally refuses"
 * is not the same guarantee as "cannot construct a malformed header" - so
 * this whitelists instead of blacklisting.
 *
 * Two parameters, per RFC 6266 / RFC 5987: a plain `filename` restricted to
 * safe printable ASCII for browsers that don't read the extended form, and
 * `filename*` carrying the real name percent-encoded, so a resume named in
 * any language still downloads with its real name in a browser that
 * supports it (all current ones do).
 */
function contentDisposition(fileName: string): string {
  const asciiFallback =
    fileName
      .replace(/[^\x20-\x7E]/g, "") // drop anything outside safe printable ASCII, including CR/LF/other control chars
      .replace(/["\\]/g, "") // quote/backslash would need escaping inside the quoted-string; simplest to just drop them
      .trim() || "resume";
  const encoded = encodeURIComponent(fileName).replace(/['()]/g, (c) => `%${c.charCodeAt(0).toString(16)}`);
  return `attachment; filename="${asciiFallback}"; filename*=UTF-8''${encoded}`;
}

/** Streams the original file back - only ever to the user who uploaded it. This is the one place a resume's bytes are ever served. */
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const document = await getDocumentById(id);
  if (!document || document.userId !== user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const bytes = await storageProvider.download(document.storageKey);
  return new NextResponse(new Uint8Array(bytes), {
    headers: {
      "Content-Type": CONTENT_TYPES[document.fileType],
      "Content-Disposition": contentDisposition(document.fileName),
      "Cache-Control": "private, no-store",
    },
  });
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const document = await getDocumentById(id);
  if (!document || document.userId !== user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await storageProvider.delete(document.storageKey);
  await deleteDocument(id);
  return NextResponse.json({ ok: true });
}
