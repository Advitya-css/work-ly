import "server-only";

import { pool } from "@/lib/db/pool";

/**
 * Fixed-window rate limiting, backed by the `rate_limits` table (see
 * prisma/migrations/20260824000000_rate_limits).
 *
 * Guards the two request paths that have a real cost behind them: the job
 * parsing pipeline calls a paid AI provider per request, and the resume
 * upload endpoint runs regex-heavy authenticity/parsing work with nothing
 * else standing between "a user clicks submit" and "the server does that
 * work" as many times a minute as the client cares to ask. Without a limit,
 * one impatient double-click, one buggy retry loop, or one deliberately
 * abusive script has unbounded AI spend or unbounded CPU cost behind it.
 *
 * The whole check-and-increment happens in a single `INSERT ... ON
 * CONFLICT` statement, not a read-then-write from application code: two
 * concurrent requests from the same user must not both read "0 requests so
 * far" and both be let through, and only the database can make that atomic.
 */

/**
 * Shared budget for every path that ends in an AI parsing call - regular
 * job submission and dream-job submission both draw from the same "job-
 * submit" bucket per user, deliberately, so the limit can't be sidestepped
 * by switching which of the two forms you submit through.
 */
export const JOB_SUBMIT_LIMIT = 20;
export const JOB_SUBMIT_WINDOW_SECONDS = 10 * 60;

export interface RateLimitResult {
  allowed: boolean;
  /** Requests already counted in the current window, including this one if allowed. */
  count: number;
  limit: number;
  /** When the current window resets and the count goes back to zero. */
  resetAt: Date;
}

/**
 * Checks and records one attempt under `key` within a `windowSeconds`
 * fixed window, capped at `limit` attempts per window.
 *
 * `userId` is stored alongside the key (not used for the check itself) so
 * account deletion can clean up by userId without needing to know every
 * `kind` prefix a user might have rows under.
 */
export async function checkRateLimit(
  kind: string,
  identity: string,
  { limit, windowSeconds, userId }: { limit: number; windowSeconds: number; userId?: string | null },
): Promise<RateLimitResult> {
  const key = `${kind}:${identity}`;

  // A window that has expired is reset to count = 1 (this attempt); a
  // window still open is incremented. Both branches happen inside the same
  // upsert, so there's no gap between reading the old value and writing the
  // new one for another concurrent request to land in.
  const { rows } = await pool.query<{ count: number; windowStart: Date }>(
    `INSERT INTO rate_limits (key, "userId", "windowStart", count)
     VALUES ($1, $2, now(), 1)
     ON CONFLICT (key) DO UPDATE SET
       count = CASE
         WHEN rate_limits."windowStart" > now() - ($3 || ' seconds')::interval
           THEN rate_limits.count + 1
         ELSE 1
       END,
       "windowStart" = CASE
         WHEN rate_limits."windowStart" > now() - ($3 || ' seconds')::interval
           THEN rate_limits."windowStart"
         ELSE now()
       END
     RETURNING count, "windowStart"`,
    [key, userId ?? null, String(windowSeconds)],
  );

  const row = rows[0];
  const count = Number(row.count);
  const resetAt = new Date(new Date(row.windowStart).getTime() + windowSeconds * 1000);

  return { allowed: count <= limit, count, limit, resetAt };
}

/** Minutes-until-reset, rounded up, for a user-facing "try again in N minutes" message. */
export function minutesUntil(resetAt: Date): number {
  return Math.max(1, Math.ceil((resetAt.getTime() - Date.now()) / 60_000));
}
