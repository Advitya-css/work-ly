-- Rate limiting for the two request paths with real cost behind them: the
-- job-parsing pipeline (calls a paid AI provider) and the resume upload
-- endpoint (regex-heavy authenticity/parsing work with no other limit on
-- how often one user can trigger it). Without this, one user - or one bug
-- in a retry loop - can run up unbounded AI spend or unbounded CPU cost.
--
-- One row per (kind, identity) pair, holding a fixed-window counter. The
-- app owns the window logic (see lib/rate-limit.ts); this table is just
-- durable, race-safe storage for it, backed by a single atomic
-- INSERT ... ON CONFLICT so two concurrent requests from the same user
-- can't both read "0 so far" and both be allowed through.
--
-- A plain table rather than an in-memory counter deliberately: this app can
-- run as more than one server process, and a limit that only one process
-- knows about is not a limit.

CREATE TABLE IF NOT EXISTS "rate_limits" (
  "key"          TEXT PRIMARY KEY,
  "userId"       TEXT,
  "windowStart"  TIMESTAMPTZ NOT NULL,
  "count"        INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS "rate_limits_userId_idx" ON "rate_limits" ("userId");
