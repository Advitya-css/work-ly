/**
 * Realistic fictional job postings used to populate a new user's
 * Opportunities page with something to look at before they've pasted a
 * single real job - spans industries, seniority levels, locations and
 * (once run through the real pipeline against the user's own profile)
 * a natural spread of match quality. These are fed through the exact same
 * parse -> analyze -> prioritize pipeline as a pasted job - nothing about
 * the resulting Fit/Priority/gaps is hand-authored or fabricated, only the
 * posting text itself is fictional.
 */
export interface DemoJob {
  title: string;
  company: string;
  text: string;
}

export const DEMO_JOBS: DemoJob[] = [
  {
    title: "Product Analyst",
    company: "Northwind Retail",
    text: `Product Analyst
Company: Northwind Retail
Location: London, United Kingdom
Employment Type: Full-time
Work Mode: Hybrid

About the role:
Northwind Retail is hiring a Product Analyst to help the product team understand user behavior across our e-commerce platform and turn it into clear recommendations.

Requirements (must have):
- 2+ years of experience in an analyst or data-focused role
- Strong SQL skills for querying large datasets
- Experience building dashboards or reports for stakeholders
- Bachelor's degree in a quantitative field or equivalent experience

Preferred:
- Experience with Python or R for analysis
- Familiarity with A/B testing and experimentation
- Prior experience in e-commerce or retail

Salary: GBP 45,000 - 58,000
Industry: Retail
Seniority: Mid
Deadline: 2026-11-15`,
  },
  {
    title: "Senior Frontend Engineer",
    company: "Fernwood Digital",
    text: `Senior Frontend Engineer
Company: Fernwood Digital
Location: Remote, United States
Employment Type: Full-time
Work Mode: Remote

About the role:
Fernwood Digital is looking for a Senior Frontend Engineer to own key parts of our customer dashboard and mentor engineers on the team.

Requirements (must have):
- 5+ years of experience with JavaScript and React
- Strong proficiency in TypeScript
- Experience with REST APIs
- Bachelor's degree in Computer Science or related field

Preferred:
- Experience with Node.js
- Familiarity with design systems
- Experience with automated testing

Salary: USD 135,000 - 165,000
Industry: Software
Seniority: Senior
Deadline: 2026-12-05`,
  },
  {
    title: "Backend Engineer (Go)",
    company: "Ironclad Systems",
    text: `Backend Engineer (Go)
Company: Ironclad Systems
Location: Berlin, Germany
Employment Type: Full-time
Work Mode: Onsite

About the role:
Ironclad Systems builds high-throughput infrastructure for logistics companies. We're hiring a Backend Engineer to work on our core routing service in Go.

Requirements (must have):
- 3+ years of backend engineering experience
- Proficiency in Go
- Experience with distributed systems
- Experience with Kubernetes
- Fluent German language skills (B2+)

Preferred:
- Experience with Kafka
- Contributions to open source infrastructure projects

Salary: EUR 70,000 - 85,000
Industry: Infrastructure
Seniority: Mid
Deadline: 2026-10-20`,
  },
  {
    title: "Staff Frontend Engineer",
    company: "Vantage Labs",
    text: `Staff Frontend Engineer
Company: Vantage Labs
Location: San Francisco, United States
Employment Type: Full-time
Work Mode: Hybrid

About the role:
Vantage Labs is looking for a Staff Frontend Engineer to set frontend architecture direction across the org and lead our design system strategy.

Requirements (must have):
- 8+ years of frontend engineering experience
- Deep expertise in React, TypeScript, and performance optimization at scale
- Proven track record setting technical direction across multiple teams
- Experience owning a design system used by 10+ product teams

Preferred:
- Experience speaking at conferences or publishing technical writing
- Experience with micro-frontend architectures

Salary: USD 195,000 - 235,000
Industry: Software
Seniority: Lead
Deadline: 2026-11-30`,
  },
  {
    title: "UX Researcher",
    company: "BrightPath Health",
    text: `UX Researcher
Company: BrightPath Health
Location: New York, United States
Employment Type: Full-time
Work Mode: Hybrid

About the role:
BrightPath Health is looking for a UX Researcher to lead qualitative and quantitative research for our patient-facing products.

Requirements (must have):
- 4+ years of experience in UX research
- Experience designing and running usability studies
- Experience synthesizing research into actionable insights for product teams
- Master's degree in Human-Computer Interaction, Psychology, or related field

Preferred:
- Experience in healthcare or regulated industries
- Familiarity with survey design and statistical analysis

Salary: USD 110,000 - 130,000
Industry: Healthcare
Seniority: Mid
Deadline: 2026-10-10`,
  },
  {
    title: "Data Analyst",
    company: "Meridian Bank",
    text: `Data Analyst
Company: Meridian Bank
Location: Chicago, United States
Employment Type: Full-time
Work Mode: Onsite

About the role:
Meridian Bank is hiring a Data Analyst to support the risk and operations teams with reporting and analysis.

Requirements (must have):
- 2+ years of experience working with SQL and relational databases
- Experience building reports and dashboards
- Strong attention to detail
- Bachelor's degree in a quantitative field

Preferred:
- Experience with Tableau or Power BI
- Experience in banking or financial services

Salary: USD 75,000 - 90,000
Industry: Financial Services
Seniority: Junior
Deadline: 2026-10-25`,
  },
  {
    title: "Engineering Manager",
    company: "Horizon Cloud",
    text: `Engineering Manager
Company: Horizon Cloud
Location: Remote, United States
Employment Type: Full-time
Work Mode: Remote

About the role:
Horizon Cloud is hiring an Engineering Manager to lead a team of 6-8 engineers building our platform APIs.

Requirements (must have):
- 7+ years of software engineering experience, including people management
- Experience mentoring and growing engineers
- Experience with distributed systems or platform engineering
- Track record of shipping complex projects on time

Preferred:
- Prior experience as an individual contributor in a similar tech stack
- Experience with hiring and team building

Salary: USD 175,000 - 210,000
Industry: Software
Seniority: Lead
Deadline: 2026-12-15`,
  },
  {
    title: "Junior Frontend Developer",
    company: "Pixel Forge",
    text: `Junior Frontend Developer
Company: Pixel Forge
Location: Austin, United States
Employment Type: Full-time
Work Mode: Onsite

About the role:
Pixel Forge is a small design studio looking for a Junior Frontend Developer to help build marketing sites and small web apps for clients.

Requirements (must have):
- 0-2 years of experience with HTML, CSS, and JavaScript
- Willingness to learn React
- Good communication skills for working directly with clients

Preferred:
- Experience with Figma or similar design tools
- A portfolio of personal or client projects

Salary: USD 55,000 - 65,000
Industry: Design
Seniority: Entry
Deadline: 2026-10-05`,
  },
  {
    title: "Product Manager",
    company: "Northwind Retail",
    text: `Product Manager
Company: Northwind Retail
Location: London, United Kingdom
Employment Type: Full-time
Work Mode: Hybrid

About the role:
Northwind Retail is hiring a Product Manager to own the checkout and payments experience across our e-commerce platform.

Requirements (must have):
- 5+ years of product management experience
- Experience shipping consumer-facing products end to end
- Experience working directly with engineering and design teams
- Strong written and verbal communication skills

Preferred:
- Experience in payments or e-commerce
- Experience with experimentation and A/B testing

Salary: GBP 85,000 - 105,000
Industry: Retail
Seniority: Senior
Deadline: 2026-11-20`,
  },
  {
    title: "Full Stack Engineer",
    company: "Riverstone Fintech",
    text: `Full Stack Engineer
Company: Riverstone Fintech
Location: Remote, Canada
Employment Type: Full-time
Work Mode: Remote

About the role:
Riverstone Fintech is building tools to help small businesses manage cash flow. We're hiring a Full Stack Engineer to work across our React frontend and Node.js backend.

Requirements (must have):
- 4+ years of experience with JavaScript or TypeScript
- Experience with React
- Experience with Node.js and REST APIs
- Experience with relational databases such as PostgreSQL

Preferred:
- Experience in fintech or payments
- Experience with CI/CD pipelines

Salary: CAD 110,000 - 135,000
Industry: Fintech
Seniority: Mid
Deadline: 2026-11-01`,
  },
  {
    title: "DevOps Engineer",
    company: "Ironclad Systems",
    text: `DevOps Engineer
Company: Ironclad Systems
Location: Berlin, Germany
Employment Type: Full-time
Work Mode: Hybrid

About the role:
Ironclad Systems is hiring a DevOps Engineer to improve our deployment pipelines and infrastructure reliability.

Requirements (must have):
- 3+ years of experience with cloud infrastructure (AWS, GCP, or Azure)
- Experience with Kubernetes and Docker
- Experience building CI/CD pipelines
- Experience with infrastructure as code (Terraform or similar)

Preferred:
- Experience with observability tooling (Prometheus, Grafana)
- Fluent German language skills

Salary: EUR 75,000 - 90,000
Industry: Infrastructure
Seniority: Mid
Deadline: 2026-10-30`,
  },
  {
    title: "Senior Product Analyst",
    company: "Lumen Analytics",
    text: `Senior Product Analyst
Company: Lumen Analytics
Location: Remote, United States
Employment Type: Contract
Work Mode: Remote

About the role:
Lumen Analytics helps SaaS companies understand product usage. We're hiring a Senior Product Analyst to lead analysis for a portfolio of client accounts.

Requirements (must have):
- 5+ years of experience in product analytics or data analysis
- Advanced SQL skills
- Experience presenting analysis and recommendations to stakeholders
- Bachelor's degree in a quantitative field or equivalent experience

Preferred:
- Experience with Python for data analysis
- Experience with product analytics tools like Amplitude or Mixpanel
- Experience working with SaaS companies

Salary: USD 115,000 - 140,000 (contract, annualized)
Industry: Software
Seniority: Senior
Deadline: 2026-11-10`,
  },
  {
    title: "Summer Data Analytics Intern",
    company: "Northwind Retail",
    text: `Summer Data Analytics Intern
Company: Northwind Retail
Location: London, United Kingdom
Employment Type: Internship
Work Mode: Hybrid

About the role:
Northwind Retail's product team runs a 10-week summer internship for a student who wants real analytics experience before graduating, not busywork. You will work alongside the same analysts who work on the live e-commerce platform, and the internship is scoped to give you a portfolio piece you can point to in your first full-time job search.

Requirements (must have):
- Currently enrolled in an undergraduate degree, or a recent graduate
- Comfortable with SQL fundamentals (joins, aggregation)
- Comfortable with spreadsheets or a scripting language for basic analysis

Preferred:
- Coursework or a personal project involving Python or R
- Interest in e-commerce or retail

Salary: GBP 2,400 per month (paid internship)
Industry: Retail
Seniority: Entry
Deadline: 2027-02-15`,
  },
  {
    title: "Part-Time Support Associate",
    company: "Fernwood Digital",
    text: `Part-Time Support Associate
Company: Fernwood Digital
Location: Remote, United States
Employment Type: Part-time
Work Mode: Remote

About the role:
Fernwood Digital is hiring a part-time Support Associate to help customers over chat and email, roughly 20 hours a week with a flexible schedule. A common fit is a student who needs income around a class schedule; several people on the support team started here as students.

Requirements (must have):
- Clear written communication
- Comfortable learning a new software product quickly
- Available at least 20 hours a week, flexible on which hours

Preferred:
- Prior customer-facing experience, in any industry
- Interest in eventually moving into a product or engineering role

Salary: USD 22 per hour
Industry: Software
Seniority: Entry
Deadline: 2026-12-01`,
  },
];
