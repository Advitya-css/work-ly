import { NextResponse } from "next/server";

import { getCurrentUser } from "@/lib/auth";
import { parseDocumentAndBuildProfile } from "@/lib/career/parse-document";
import { safeMessage } from "@/lib/errors";
import { checkRateLimit, minutesUntil } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const maxDuration = 60;

// Each call runs the AI resume-extraction provider (or the heuristic
// fallback's regex passes) plus the authenticity/grounding checks - real
// cost every time, and nothing else stands between a client and calling
// this repeatedly on the same or different documents.
const RESUME_PARSE_LIMIT = 10;
const RESUME_PARSE_WINDOW_SECONDS = 10 * 60;

export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const rateLimit = await checkRateLimit("resume-parse", user.id, {
    limit: RESUME_PARSE_LIMIT,
    windowSeconds: RESUME_PARSE_WINDOW_SECONDS,
    userId: user.id,
  });
  if (!rateLimit.allowed) {
    return NextResponse.json(
      { error: `Too many requests. Please try again in ${minutesUntil(rateLimit.resetAt)} minute(s).` },
      { status: 429 },
    );
  }

  const { id } = await params;

  try {
    const result = await parseDocumentAndBuildProfile(id, user.id);
    return NextResponse.json(result);
  } catch (error) {
    // Sanitized before it crosses the wire: this response is rendered in
    // the browser, and the underlying failure can be a database or AI
    // error whose text is not safe to show. See lib/errors.ts.
    return NextResponse.json(
      { error: safeMessage(error, "POST /api/documents/[id]/parse", "We couldn't read that file.") },
      { status: 422 },
    );
  }
}
